<template>
    <div class="container-fluid">
            <div class="row table-container" style="overflow-y:auto;">
                <table class="table table-bordered table-hover">
                    <thead>
                    <tr>
                    <th>Vaccine</th>
                    <th>Date Received</th>
                    <th>Status</th>
                    </tr>
                </thead>
                <tbody
                >
                    <tr 
                    v-for="row in tempList" 
                    :key="row.vaccine" 
                    :class="row.ConsumerStatus=='Consumer marked incorrect'?'incorrect':''"
                     @click="selectRow($event,row)"
                    id="table-body-row"
                    >
                        <td>{{row.vaccine}}</td>
                        <td>{{row.DateReceived}}</td>
                        <td>{{row.status}}</td>
                    </tr>
                </tbody>
                    </table>
            </div>
            <div class="row justify-content-center">
                <div class="col justify-content-center">
                    <div class="custom-control custom-switch justify-content-center switch">
                        <input type="checkbox" class="custom-control-input" id="customSwitches"  
                        v-model="showInactives" 
                        @change="onChangeEventHandler()" >
                        <label class="custom-control-label" for="customSwitches">Show Inactives</label>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-1 justify-content-right">
                    <div id="color"></div>
                </div>
                <div class="col-md-11 justify-content-left">
                <p>Consumer has flagged issues with this entry</p>
                </div>
            </div>
    </div>
</template>


<script>
export default {
    name: 'app-table',
    props:['vaccineHistory'],
    data: function(){
        return{
            showInactives:'true',
             vaccineHistoryList:this.vaccineHistory,
             tempList:[],
             locale:''
        }
    },
    mounted(){
        this.tempList=this.vaccineHistoryList.map(o => ({...o}));
    },
    watch: {
    locale: function () {      
        this.$emit('locale-changed', this.locale);
    }
    },
    methods:{
        selectRow(event,row){
            var checkboxes = document.getElementsByClassName ("selectedRow");

        for (var i=0; i<checkboxes.length; i++) {
                checkboxes[i].classList.toggle("selectedRow");
        }
           event.currentTarget.classList.toggle('selectedRow');
           this.locale = row.vaccine;
        },
         
      onChangeEventHandler(){
          if(this.showInactives){
            this.resetList();
          }
          else{
               for(let i=0;i<this.tempList.length;i++){
                   if(this.tempList[i].Active=="No"){
                        this.tempList.splice(i,1);
                   }
                }
            }
      },
        resetList() {
                    this.tempList.splice(0,this.tempList.length);
                 for(let j=0;j<this.vaccineHistoryList.length;j++){
                    this.tempList.push(this.vaccineHistoryList[j]);
                 }
        },
    
    }
}
</script>

<style scoped>
tbody>.selectedRow{
    background:rgb(99, 108, 228);
}
.incorrect {
  background: #e09e9e;
}
thead{
    background: navy;
    color:white;

}
#color{
    width:15px;
    height:15px;
    background: #e09e9e;
    border: 1px solid black;
}
th{
    position:inherit;
    width:300px;
}
#table-body-row{
    position:relative;
}
table{
    border:1px solid navy;
    width:300px;
    font-size: 13px;
    }
.table-container{
    height:60%;
    overflow:auto;
    width:300px;
    }
    .switch{
        font-size: 13px;
        font-weight: bold;
        color:navy;
    }
    p{
        font-size: 12px;
    }
</style>