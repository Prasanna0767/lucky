<template>
    <div class="container-fluid">
        <div class="row tableFixHead">
            <app-table :vaccineHistory=vaccinHistory @locale-changed = 'localewatch' ></app-table>
        </div>
        <div class="row">
                <h4>Entries from Consumer</h4>
                <textarea v-model="customerinput" rows="7"/>
        </div>
    </div>
</template>


<script>
import AppTable from './TableComponent.vue'

export default {

    name: 'app-vaccine-history',
    props: ['vaccinationHistory','customerInput'],
    components:{
        AppTable
    },
    data:function(){
        return{
            locale: '',
            customerinput:this.customerInput,
            vaccinHistory: this.vaccinationHistory,
        }
    },
    methods:{
        localewatch: function (val) {
            this.locale = val;
        }
    },
     watch: {
        locale: function () {
            this.$emit('locale-changed', this.locale);
        }
    },

}
</script>

<style scoped>
    textarea{
        width:300px;
        height:40%;
        background: rgb(226, 215, 153);
        margin:0;
        overflow:auto;
        font-size:13px;
    }
    
h4{
    color: rgb(121, 19, 19);
    border: 1px solid black;
    font-size: 15px;
    font-weight: bold;
    width:300px;
    margin:0;
}

</style>