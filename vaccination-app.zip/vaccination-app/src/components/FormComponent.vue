<template>
    <div class="container-fluid">
        <form role="form" class="col-md-12">
            <div class="form-group" id="myform">
                <!-- vaccine name -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                    <label for="vaccinename" class="form-label">Vaccine : </label></div>
                    <div class="col-md-9">
                        <input type="text" v-model="vaccinename" class="form-control" name="vaccinename" id="vaccinename" list="vaccine" 
                        @change="updatefields" :disabled=disableprop />

                        <datalist id="vaccine">
                            <option class="form-control"  v-for="item in vaccinationList" :key="item.vaccine">{{item.vaccine}}</option>
                        </datalist>
                    </div>
                </div>
                <!-- Other name/Disease -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                    <label for="brandname" class="form-label">Other Name/Disease : </label>
                    </div>
                    <div class="col-md-6">
                        <input type="text" :disabled=disableprop v-model="othername" class="form-control" name="brandname" id="brandname" list="brand"/>
                        <datalist id="brand">
                            <option class="form-control" v-for="item in diseasesCovered" :key="item.Brandname">{{item.Brandname}}</option>
                        </datalist>
                    </div>
                    <!-- ConsumerStatus: seen or incorrect -->
                    <div class="col-md-3" id="ConsumerStatus" :class="ConsumerStatus=='Consumer Seen'?'seen':'incorrect'">
                        {{ ConsumerStatus }}
                    </div>
                </div>
                <!-- date received -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                    <label for="datereceived" class="form-label">Date Received : </label>
                    </div>
                    <div class="col-md-9">
                        <input type="text" :disabled=disableprop v-model="DateReceived" class="form-control" name="datereceived" id="datereceived" >
                    </div>
                </div>
                <!-- Status -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                        <label for="status" class="form-label">Status : </label>
                    </div>
                    <div class="col-md-9">
                        <select id="status" name="status" v-model="status" class="form-control" :disabled=disableprop>
                            <option value="Given" selected>Given</option>
                            <option value="Not Given">Not Given</option>
                            <option value="Reaction">Reaction</option>
                            <option value="1st Dose">1st Dose</option>
                            <option value="2nd Dose">2nd Dose</option>
                        </select>
                    </div>
                </div>
                <!-- Description 1 -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                         <label for="description1" class="form-label">Description 1 : </label>
                    </div>
                    <div class="col-md-9">
                        <textarea name="description1" id="description1" cols="30" rows="1" 
                        v-model="description_1"
                        :disabled=disableprop
                        placeholder="Where Given"></textarea>
                    </div>
                </div>
                <!-- Description 2 -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                         <label for="description2" class="form-label">Description 2 : </label>
                    </div>
                    <div class="col-md-9">
                        <textarea name="description2" id="description2" cols="30" rows="1" 
                        v-model="description_2"
                        :disabled=disableprop
                        placeholder="Reactions"></textarea>
                    </div>
                </div>
                <!-- Description 3 -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                         <label for="description3" class="form-label">Description 3 : </label>
                    </div>
                    <div class="col-md-9">
                        <textarea name="description3" id="description3" cols="30" rows="1" 
                        v-model="description_3"
                        :disabled=disableprop
                        placeholder="What was the reaction?"></textarea>
                    </div>
                </div>
                <!-- Description 4 -->
                <div class="row">
                    <div class="col-md-3 justify-content-center">
                         <label for="description4" class="form-label">Description 4 : </label>
                    </div>
                    <div class="col-md-9">
                        <textarea name="description4" id="description4" cols="30" rows="1" 
                        v-model="description_4"
                        :disabled=disableprop
                        placeholder="Other Remarks"></textarea>
                    </div>
                </div>
                <!-- View Consumer Side -->
                    <div class="form-check justify-content-center">
                         <label for="viewConsumerSide" class="form-check-label">Do not view on Consumer side: </label>
                        <input type="checkbox" class="form-check-input" id="viewConsumerSide" value="" :disabled=disableprop />
                    </div>
                <!-- Include in Discharge Summary -->
                    <div class="form-check justify-content-center">
                         <label for="includeDischargeSummary" class="form-check-label">Include in Discharge Summary: </label>
                        <input type="checkbox" class="form-check-input" id="includeDischargeSummary" value="" :disabled=disableprop />
                    </div>
                    
                <!-- Add Note Section -->
                    <div class="row justify-content-center">
                        <button class="btn btn-primary" type="button" id="showModal" data-toggle="modal" data-target="#itemNotesModal" :disabled=disableaddnote @click="addNote">Add Note</button>
                        <!-- Add note Section -->
                        <!-- <Modal :ItemNotes=Item_Notes v-if="showModal"></Modal> -->
                        <div class="modal fade" id="itemNotesModal" tabindex="-1" role="dialog" aria-labelledby="itemNotesModalLabel" aria-hidden="true">
                            <div class="modal-dialog" role="document">
                                <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title" id="itemNotesModalLabel">Notes</h5>
                                </div>
                                <div class="modal-body">
                                                <table class="table table-bordered table-hover">
                                                    <thead>
                                                        <tr>
                                                            <th>Note</th>
                                                            <th>Author</th>
                                                            <th>Date</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        <tr id="itemdata" v-for="item in Item_Notes" :key="item.Note">
                                                            <td> <textarea type="text" name="note" class = "textarea" cols="30" rows="5" v-show='showtext' v-model="item.Note"></textarea></td>
                                                            <td><textarea type="text" name="author" class = "textarea" cols="10" rows="5" v-show='showtext' v-model="item.Author"></textarea></td>
                                                            <td><textarea type="text" name="date" class = "textarea" cols="10" rows="5" v-show='showtext'  v-model="item.Date"></textarea></td>
                                                        </tr>
                                                        <tr id="itemdata-empty">
                                                            <td> <textarea type="text" name="note" class = "textarea" cols="30" rows="5"></textarea></td>
                                                            <td><textarea type="text" name="author" class = "textarea" cols="10" rows="5" ></textarea></td>
                                                            <td><textarea type="text" name="date" class = "textarea" cols="10" rows="5"></textarea></td>
                                                        </tr>
                                                        
                                                    </tbody>
                                                </table>      
                                    </div>
                                <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                                    <button type="button" class="btn btn-primary">Save</button>
                                </div>
                                </div>
                            </div>
                        </div>
                        <!-- <app-note  :ItemNotes=Item_Notes v-show=isaddnoteclicked ></app-note> -->
                    </div>

                <!-- Active -->
                    <div class="row">
                        <label for="Active" class="form-label">Active : </label>
                        <div class="form-text" id="Active"><span>{{ Active }}</span></div>
                    </div>
                <!-- Auto Populated Section -->
                    <div class="row">
                        <div class="col-md-4">
                            <label for="dateEntered" class="form-label auto-populated">Date Entered: </label>
                            <input id="dateEntered" class="form-control" type="text" disabled v-model="DateEntered"/>
                        </div>
                        <div class="col-md-4">
                            <label for="createdBy" class="form-label auto-populated">Created By: </label>
                            <input id="createdBy" class="form-control" type="text" disabled v-model="CreatedBy"/>
                        </div>
                        <div class="col-md-4">
                            <label for="lastEditedBy" class="form-label auto-populated">Last Edited By: </label>
                            <input id="lastEditedBy" class="form-control" type="text" disabled v-model="LastEditedBy"/>
                        </div>
                    </div>
                    <br>
                <!-- Buttons Section -->
                <div class="row justify-content-center">
                    <button class="btn btn-primary" type="button" v-show="isAddHidden" @click="addEntry()">Add</button>
                    <button class="btn btn-primary" type="button" v-show="isEditHidden" @click="editEntry()">Edit</button>
                    <button class="btn btn-primary" type="button" v-show="isSaveHidden" @click.stop.prevent="saveEntry()">Save</button>                    
                    <button class="btn btn-primary" type="button" v-show="isCancelHidden" @click="cancelEntry()">Cancel</button>
                    <button class="btn btn-primary" type="button" v-show="isInActivateHidden" @click="inactivate()">Inactivate</button>
                    <button class="btn btn-primary" type="button" v-show="isActivateHidden" @click="activate()">Activate</button>


                </div>
            </div>

        </form>
    </div>
</template>


<script>
export default {
    name: 'app-form',
    props:['vaccinehistory','diseasescovered','selectedvaccineval'],
    data:function(){
        return {
            selectedvaccine:this.selectedvaccineval,
            vaccinationList:this.vaccinehistory,
            diseasesCovered:this.diseasescovered,
            consumerstatus:'',
            isSaveHidden: false,
            isCancelHidden: false,
            isAddHidden: true,
            isEditHidden: true,
            isActivateHidden:false,
            isInActivateHidden:false,
            disableprop:1,
            disableaddnote:1,
            entries:[],
            isaddnoteclicked:false,
            showModal: true,
            showtext: true,
            showempty: false
                  
        }
    },
    mounted(){
        this.init();
    },
    methods:{
        init(){
            this.disableFields();
        },
        disableFields(){
                this.disableprop = 1;
        },
        enableFields(){
                console.log('enabling');
                this.disableprop = 0;

        },
        onSearchConsumerStatus() {
            if(this.selectedvaccine !=''){
                 for(let i=0;i<this.vaccinationList.length;i++){
                        if(this.vaccinationList[i].vaccine.localeCompare(this.selectedvaccine)==0){
                            this.consumerstatus = this.vaccinationList[i].ConsumerStatus;
                        }
                 }
            }
            else{
                return '';
            }
        },
        disablefield(){
            if(this.disableprop==1){
                console.log('appar');
                return true;
            }
            else
                return false;
        },
    
    
        updatefields(val){
            for(let i=0;i<this.vaccinationList.length;i++){
                if(this.vaccinationList[i].vaccine.localeCompare(val)==0){
                            this.vaccinename = this.vaccinationList[i].vaccine!=undefined?this.vaccinationList[i].vaccine:'',
                            this.othername = this.vaccinationList[i].othername!=undefined?this.vaccinationList[i].othername:'',
                            this.DateReceived = this.vaccinationList[i].DateReceived!=undefined?this.SetFormattedDate(this.vaccinationList[i].DateReceived):'';
                            this.status = this.vaccinationList[i].status!=undefined?this.vaccinationList[i].status:'',
                            this.description_1 = this.vaccinationList[i].description_1!=undefined?this.vaccinationList[i].description_1:'',
                            this.description_2 = this.vaccinationList[i].description_2!=undefined?this.vaccinationList[i].description_2:'',
                            this.description_3 = this.vaccinationList[i].description_3!=undefined?this.vaccinationList[i].description_3:'',
                            this.description_4 = this.vaccinationList[i].description_4!=undefined?this.vaccinationList[i].description_4:'',
                            this.Active = this.vaccinationList[i].Active!=undefined?this.vaccinationList[i].Active:'';
                            this.ConsumerStatus = this.vaccinationList[i].ConsumerStatus!=undefined?this.vaccinationList[i].ConsumerStatus:'';
                            this.Item_Notes = this.vaccinationList[i].Item_Notes!=undefined?this.vaccinationList[i].Item_Notes:'';
                            this.DateEntered = this.vaccinationList[i].DateEntered!=undefined?this.vaccinationList[i].DateEntered:'';
                            this.CreatedBy = this.vaccinationList[i].CreatedBy!=undefined?this.vaccinationList[i].CreatedBy:'';
                            this.LastEditedBy = this.vaccinationList[i].LastEditedBy!=undefined?this.vaccinationList[i].LastEditedBy:'';
                    break;
                }
            }
        },
        addEntry(){
            this.isSaveHidden =true;this.isCancelHidden=true;this.isAddHidden=false;this.isEditHidden=false;this.isInActivateHidden=true;
            this.DateEntered = this.GetFormattedDate();
            this.CreatedBy = "Anonymous";
            this.LastEditedBy = "Anonymous2";
            this.Active="Yes";
            this.enableFields();
           this.resetfields();
        },
        editEntry(){

            if(this.selectedvaccineval==undefined||this.selectedvaccineval==''){
                alert("Select an entry to Edit");
            }
            else{
                this.isSaveHidden =true;this.isCancelHidden=true;this.isAddHidden=false;this.isEditHidden=false;this.isInActivateHidden=true;
                this.enableFields();
                this.disableaddnote = 0;
            }
            
        },
        addNote(){
            var myModal = document.getElementById('itemNotesModal')
            var myInput = document.getElementById('showModal')

            myModal.addEventListener('shown.bs.modal', function () {
            myInput.focus()
            });
            if(this.Item_Notes==undefined){
                document.getElementById('itemdata').style.display = "none";
                document.getElementById('itemdata-empty').style.display = "";
            }
            else{
                document.getElementById('itemdata-empty').style.display = "none";
                 document.getElementById('itemdata').style.display = "";

            }
        },
        saveEntry(){
            this.disableaddnote = 0;
            this.entries.push({
                vaccine:this.vaccinename==undefined?'':this.vaccinename,
                othername:this.othername==undefined?'':this.othername,
                DateReceived:this.DateReceived==undefined?'':this.DateReceived, 
                status:this.status==undefined?'':this.status,
                description_1:this.description_1==undefined?'':this.description_1,
                description_2:this.description_2==undefined?'':this.description_2,
                description_3:this.description_3==undefined?'':this.description_3,
                description_4:this.description_4==undefined?'':this.description_4,
                Active:this.Active==undefined?'Yes':this.Active,
                ConsumerStatus:this.ConsumerStatus==undefined?'':this.ConsumerStatus,
                Item_Notes:this.Item_Notes==undefined?'':this.Item_Notes,
                DateEntered:this.DateEntered==undefined?this.GetFormattedDate():this.DateEntered,
                CreatedBy:this.CreatedBy==undefined?"Anonymous":this.CreatedBy,
                LastEditedBy:this.LastEditedBy==undefined?"Anonymous":this.LastEditedBy
            });
            this.$emit('updateSave',this.entries);
            //this.reloadPage();
        },
        cancelEntry(){
            this.resetfields();
            this.resetCancelFields();
            this.init();
            this.reloadPage();
        },
        reloadPage(){
            window.location.reload();
        },
        inactivate(){
            this.Active="No";
            this.isActivateHidden=true;
            this.isInActivateHidden=false;
            this.saveEntry();
        },
        activate(){
            this.Active="Yes";
            this.isActivateHidden=false;
            this.isInActivateHidden=true;
            this.saveEntry();

        },
        GetFormattedDate() {
            var todayTime = new Date();
            var month = todayTime .getMonth() + 1;
            var day = todayTime .getDate();
            var year = todayTime .getFullYear();
            return month + "/" + day + "/" + year;
        },
        SetFormattedDate(dateval) {
            var parts =dateval.split('/');
            var todayTime = new Date(parts[2], parts[1] - 1, parts[0]);
            var month = todayTime .getMonth() + 1;
            var day = todayTime .getDate();
            var year = todayTime .getFullYear();
            return month + "/" + day + "/" + year;
        },
        resetfields(){

            this.vaccinename = undefined;
            this.othername = undefined;
            this.DateReceived = undefined;
            this.status = undefined;
            this.description_1 = undefined;
            this.description_2 = undefined;
            this.description_3 = undefined;
            this.description_4 = undefined;
            this.ConsumerStatus = undefined;
            this.Item_Notes = undefined;
            this.Active=undefined;
        },
        resetCancelFields(){
            this.DateEntered=undefined;
            this.CreatedBy=undefined;
            this.LastEditedBy=undefined;
        }
    },
    watch:{
        selectedvaccineval: function(newVal) {
            this.updatefields(newVal);
        },
        disableprop:function(){
            this.disablefield();
        },
    }
    
}
</script>

<style scoped>
#vaccinename,
#brandname,
#datereceived,
#status,
#description1,
#description2,
#description3,
#description4{
    width:250px;
    height:30px;
    font-size:13px;

}
#description1,
#description2,
#description3,
#description4{
    overflow:auto;
}
.form-check-label{
    padding-right:20px;
    margin-right:20px;
    text-align: center;
}
.form-check-input{
    padding-left:20px;
    margin-left:20px;
    align-self: center;
}

label{
    font-weight:bold;
    font-size:15px;
    float:left;
}
button{
        font-size: 12px;
        text-align:center;
        padding:2px 2px 2px 2px;
        margin:2px;
        font-style:initial;
        background: navy;
        font-weight: bold;
        width: 80px;
}
disabled{
    background: gray;
}
label{
    font-size: 13px;
}
#dateEntered,
#createdBy,
#lastEditedBy{
    height:30px;
    width:100px;
    font-size:13px;
}
.seen{
    color: indigo;
    font-weight: bold;
    font-size:13px;
}
.incorrect{
    color: red;
    font-weight: bold;
    font-size:13px;

}
table{
    border:1px solid navy;
    width:300px;
    font-size: 13px;
    background: white;
    }
thead{
    background: navy;
    color:white;
    width:100%;
    padding:0;
    margin:0;
}
th{
    position:inherit;
    width:300px;
    padding:0;
    margin:0;
}
#itemNotesModal{
    position: fixed;
    width:80%;
    height:80%;
}
</style>