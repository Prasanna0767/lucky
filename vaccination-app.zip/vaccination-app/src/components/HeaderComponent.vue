<template>
    <div class="container-fluid header-inner">
            <div class="row title">
                <div class="col">
                    <p>Vaccination History</p>
                </div>
            </div>
            <div class="row content">
                <div class="col">
                   PID:  <strong>{{ patientDetails.PID }}</strong>
                </div>
                <div class="col">
                   Name:  <strong>{{ patientDetails.Name }}</strong>
                </div>
                <div class="col">
                   DOB:  <strong>{{ patientDetails.DOB }}</strong>
                </div>
                <div class="col">
                   Address: <strong> {{ patientDetails.Address }}</strong>
                </div>
                <div class="col">
                    <button class="btn btn-primary" id="p-profile" v-on:click="getPatientProfile">Patient Profile</button>
                </div>
                <div class="col">
                    <button class="btn btn-primary" id="p-search" v-on:click="getPatientSearch">Patient Search</button>
                </div>
            </div>
    </div>
</template>


<script>
export default {
    name: 'app-header',
    props: ['patientDetails'],
    methods:{
        getPatientProfile: function () {
                //Code tp navigate to Patient Profile Page
        },
        getPatientSearch: function () {
                //Code tp navigate to Patient Seharc Page

        },
    }
}
</script>

<style scoped>
.title{
    background: navy;
    text-align: left;
    font-size: 15px;
    color: white;
    height: 25px;
    padding: 1px;
}
.content{
    padding:2px 2px 2px 2px;
    font-size: 12px;
    text-align: justify;
    
}
#p-profile,#p-search{
        font-size: 12px;
        text-align:justify;
        padding:2px 2px 2px 2px;
        margin:2px;
        font-style:initial;
        background: navy;
        font-weight: bold;
}
.header-inner{
    background:white;
}
</style>