<template>
    <div class="container-fluid">
        <div class="row">
            <h4>Vaccination History</h4>
            <app-vaccine-history :vaccinationHistory=vaccinationHistory :customerInput=customerInputs @locale-changed = "localechangedval"></app-vaccine-history>
        </div>

    </div>
</template>


<script>

import AppVaccineHistory from './VaccineHistoryComponent.vue'

export default {
    name: 'app-history',
    components:{
        AppVaccineHistory
    },
    props:['vaccineHistory','consumerInput'],
    data: function(){
    return {
        vaccinationHistory:this.vaccineHistory,
        customerInputs:this.consumerInput,
        locale:'',
        }
    },
    methods:{
        localechangedval: function (val) {
            this.locale = val;
    }

    },
     watch: {
        locale: function () {
            this.$emit('locale-changed', this.locale);
        },
    },

}
</script>

<style scoped>
h4{
    color: navy;
    border: 1px solid black;
    font-size: 15px;
    font-weight: bold;
    width:300px;
    margin:0;
}
</style>