<template>
  <div class="container-fluid home">
    <div class="row header">
      <app-header :patientDetails="patientDetails"></app-header>
    </div>

    <div class="container-fluid body-content">
      <div class="row justify-content-center">
          <div class="col-md-4">
              <app-history  :vaccineHistory=vaccineHistory :consumerInput="customerInput" @locale-changed="localeChanged"></app-history>
          </div>
          <div class="col-md-8">
              <app-form :vaccinehistory='(temp.length!=0)?temp:vaccineHistory' :diseasescovered="Brandname" :selectedvaccineval = "locale" @update-save="updateVaccineHistory"></app-form>
          </div>
      </div>
    </div>
  </div>
</template>

<script>

import AppForm from './components/FormComponent.vue'
import AppHistory from './components/HistoryComponent.vue'
import AppHeader from './components/HeaderComponent.vue'

//import Vue from 'vue'

export default {
  name: 'App',
  components: {
    AppForm,
    AppHistory,
    AppHeader
  
  },
  data: function(){
    return {
      locale:'',
      newvalueFromchild:[],
      temp:[],
      patientDetails:
        {
          PID:"1221335622",Name: "John", DOB: "23-07-1991", Address: "5 Main St, TAS 7028"
        },
      vaccineHistory:
        [
            {
                vaccine:"Hepatitis B",
                othername:"Other Diseases covered",
                DateReceived:"25/02/2021", 
                status:"Given",
                description_1:"GP",
                description_2:"Yes",
                description_3:"Local Swelling",
                description_4:"Local reactions was mild. No interventions Done.",
                Active:"Yes",
                ConsumerStatus:"Consumer Seen",
                Item_Notes:[
                    {
                            Note:"Antibodies of Hep B Done,Pt has the Immunity.",
                            Author:"Joe Noel(Doctor)",
                            Date:"7/25/2021"
                    },
                ],
                DateEntered:"25/02/2021",
                CreatedBy:"Anonymous",
                LastEditedBy:"25/07/2021"

            },
            {
                vaccine:"Pneumococcal",
                othername:"Other Diseases covered",
                DateReceived:"05/10/1970", 
                status:"Given",
                description_1:"",
                description_2:"",
                description_3:"",
                description_4:"",
                Active:"Yes",
                ConsumerStatus:"Consumer marked incorrect",
                Item_Notes:[
                    {
                            Note:"Antibodies of Pneumococcal is given",
                            Author:"Joe Noel(Doctor)",
                            Date:"25/07/2021"
                    },
                ],
                DateEntered:"25/02/2021",
                CreatedBy:"Anonymous",
                LastEditedBy:"25/07/2021"
            },
            {
                vaccine:"Influenza",
                othername:"Other Diseases covered",
                DateReceived:"05/10/1970", 
                status:"Given",
                description_1:"",
                description_2:"",
                description_3:"",
                description_4:"",
                Active:"Yes",
                ConsumerStatus:"Consumer Seen",
                Item_Notes:[
                    {
                            Note:"Antibodies of Pneumococcal is given",
                            Author:"Joe Noel(Doctor)",
                            Date:"25/07/2021"
                    },
                ],
                DateEntered:"25/02/2021",
                CreatedBy:"Anonymous",
                LastEditedBy:"25/07/2021"
            },
            {
                vaccine:"Covid 19",
                othername:"Other Diseases covered",
                DateReceived:"10/04/2021", 
                status:"1st Dose",
                description_1:"",
                description_2:"",
                description_3:"",
                description_4:"",
                Active:"Yes",
                ConsumerStatus:"Consumer Seen",
                Item_Notes:[
                    {
                            Note:"Antibodies of Hep B Done,Pt has the Immunity.",
                            Author:"Joe Noel(Doctor)",
                            Date:"25/07/2021"
                    },
                ],
                DateEntered:"25/02/2021",
                CreatedBy:"Anonymous",
                LastEditedBy:"25/07/2021"

            },
            {
                vaccine:"Not Active",
                othername:"Other Diseases covered",
                DateReceived:"10/04/2021", 
                status:"Given",
                description_1:"",
                description_2:"",
                description_3:"",
                description_4:"",
                Active:"No",
                ConsumerStatus:"Consumer Seen",
                Item_Notes:[
                    {
                            Note:"Antibodies of Hep B Done,Pt has the Immunity.",
                            Author:"Joe Noel(Doctor)",
                            Date:"25/07/2021"
                    },
                ],
                DateEntered:"25/02/2021",
                CreatedBy:"Anonymous",
                LastEditedBy:"25/07/2021"

            }

        ],
      customerInput:"Hepatitis B - (21/02/1965)\nPneumococcal\nInfluenza - (04/02/2021)\nCovid 19 - (10/04/1965)\nPertussis",
      Brandname:[
        {
          Brandname:"Cipla", DiseasesCovered:"hepatitis"
        },
        {
          Brandname:"Pfizer", DiseasesCovered:"hepatitis"
        },

      ],
    }
  },
  methods:{
    localeChanged: function (val) {
      this.locale=val;
    },
    updateVaccineHistory:function(val){
        this.newvalueFromchild=val;
    },
    updateNewValues(){
      var index = -1;
      for(let i=0;i<this.vaccineHistory.length;i++){
            if(this.vaccineHistory[i].vaccine == this.newvalueFromchild[0].vaccine){
              index = i;
              break;
            } 
        }
      if(index==-1){
                this.vaccineHistory.push(this.newvalueFromchild[0]);
            }
            else{
                      this.temp = this.vaccineHistory.splice(index, 1, this.newvalueFromchild[0]).map(o => ({...o}));
                                this.vaccineHistory = JSON.stringify(this.temp);

                                }
    },
  },
  watch:{
    newvalueFromchild: function(){
        this.updateNewValues();
    },
  },
}
</script>

<style>

.body-content{
  cursor: pointer;
  background:rgba(236, 236, 234, 1);
  padding:5px;
  margin:0;
  width:100%;
  height:100%;
}
.header{
  margin-bottom: 5px;
  border: 1px solid black;
}
.home{
  height:100%;
  width:100%;
}
</style>